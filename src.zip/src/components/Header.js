import React, { Fragment } from 'react'


function Header() {
    return (
        <Fragment>
            <header>
                <nav id="logo">
                    <h1> ExyNews</h1>
                </nav>
                <ul id="head">
                    <li>Home</li>
                    <li>Sport</li>
                    <li>Entertainment</li>
                    <li>LifeStyle</li>
                    <li>Travel</li>
                    <li>politics</li>
                    <li>Bussiness</li>


                </ul>
            </header>
        </Fragment>
    )
}

export default Header
