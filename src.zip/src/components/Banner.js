import React from 'react'

function Banner({ banner }) {
    return (
        <div>

        </div>
    )
}

export default Banner
